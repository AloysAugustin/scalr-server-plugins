#!/usr/bin/env python

def blah():
    return "Blah"
